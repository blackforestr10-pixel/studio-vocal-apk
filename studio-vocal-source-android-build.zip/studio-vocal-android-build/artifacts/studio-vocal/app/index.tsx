import { useRef, useState, type ComponentRef } from 'react';
import { ActivityIndicator, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import Slider from '@react-native-community/slider';
import * as Haptics from 'expo-haptics';
import { studioColors as c } from '@/constants/colors';
import { useStudio } from '@/audio/useStudio';
import type { Channel } from '@/audio/runtime';
import { Arrangement, Mixer } from '@/components/Arrangement';
import { BeatEditor } from '@/components/BeatEditor';
import { VocalRack } from '@/components/VocalRack';
import { Action, styles as common, timecode } from '@/components/dawPrimitives';

const tabs = [
  { id: 'arrange', title: 'Proiect', icon: 'layers' },
  { id: 'insert', title: 'Rack vocal', icon: 'sliders' },
  { id: 'beat', title: 'Beat Maker', icon: 'grid' },
  { id: 'mix', title: 'Mixer', icon: 'bar-chart-2' },
] as const;
type Panel = typeof tabs[number]['id'];

export default function StudioScreen() {
  const studio = useStudio();
  const insets = useSafeAreaInsets();
  const scroller = useRef<ComponentRef<typeof ScrollView>>(null);
  const [panel, setPanel] = useState<Panel>('arrange');
  const [channel, setChannel] = useState<Channel>('voice');
  const [scrub, setScrub] = useState<number | null>(null);
  const [confirmRecord, setConfirmRecord] = useState(false);
  const { tracks, settings, recording, blocked, hasBeat, playback } = studio;
  const hasAudio = Boolean(tracks.voice || tracks.music || hasBeat);
  const locked = blocked || recording;
  const top = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top + 8;
  const bottom = Platform.OS === 'web' ? Math.max(insets.bottom, 34) : insets.bottom + 6;
  const position = scrub ?? studio.position;
  const step = playback.playing && hasBeat && position >= studio.backingStart && position < studio.backingStart + studio.beatLength
    ? Math.floor((position - studio.backingStart) * settings.beat.bpm / 15) % 16 : -1;
  const clock = recording ? studio.recorderState.durationMillis / 1000 : position;

  function go(next: Panel) {
    setPanel(next);
    scroller.current?.scrollTo({ y: 0, animated: false });
  }

  function record(force = false) {
    if (Platform.OS !== 'web') void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    if (!recording && tracks.voice && !force) { setConfirmRecord(true); return; }
    setConfirmRecord(false);
    if (!recording) { setChannel('voice'); go('arrange'); }
    studio.record();
  }

  return <View style={st.page}>
    <StatusBar style="light" />
    {studio.worker}
    <View style={st.shell}>
      <View style={[st.header, { paddingTop: top }]}>
        <View style={st.identity}>
          <View style={st.brandMark}><Feather name="activity" size={23} color={c.cyan} /></View>
          <View><Text style={st.name}>Studio Vocal</Text><Text style={common.cap}>PRODUCTION WORKSTATION</Text></View>
        </View>
        <Action label="Exportă mixul WAV" icon="download" text="WAV" color={c.cyan} disabled={locked || !hasAudio} onPress={studio.exportMix} />
      </View>
      <View style={st.subHeader}>
        <View style={st.projectTag}><View style={st.projectDot} /><Text style={st.projectName}>Sesiune locală</Text></View>
        <View style={st.flags}><Text style={st.flag}>{settings.beat.bpm} BPM</Text><Text style={st.flag}>4/4</Text><Text style={st.flag}>44,1 kHz</Text></View>
      </View>
      {(studio.message || studio.busy) && <View style={st.notice} accessibilityLiveRegion="polite">
        {studio.busy ? <ActivityIndicator color={c.cyan} size="small" /> : <Feather name="info" color={c.amber} size={16} />}
        <Text style={[common.muted, st.noticeText]}>{studio.busy ?? studio.message}</Text>
        {!studio.busy && studio.micSettings && <Action label="Deschide setările microfonului" icon="settings" onPress={studio.openMicSettings} />}
      </View>}
      {confirmRecord && <View style={st.notice}>
        <Text style={[common.muted, st.noticeText]}>Înlocuiești vocea curentă cu o nouă înregistrare?</Text>
        <Action label="Anulează înregistrarea" icon="x" onPress={() => setConfirmRecord(false)} />
        <Action label="Înregistrează din nou" icon="check" active onPress={() => record(true)} disabled={locked} />
      </View>}
      <ScrollView ref={scroller} style={st.scroll} contentContainerStyle={st.content} showsVerticalScrollIndicator>
        {panel === 'arrange' && <Arrangement studio={studio} selected={channel} select={setChannel} open={go} />}
        {panel === 'insert' && <VocalRack settings={settings} update={studio.update} disabled={locked} />}
        {panel === 'beat' && <BeatEditor beat={settings.beat} update={studio.updateBeat} disabled={locked} activeStep={step} />}
        {panel === 'mix' && <Mixer studio={studio} />}
      </ScrollView>
      <View style={[st.bottom, { paddingBottom: bottom }]}>
        <View style={st.transport}>
          <Action label={playback.playing ? 'Pune pauză' : 'Redă mixul'} icon={playback.playing ? 'pause' : 'play'}
            color={c.green} active={playback.playing} disabled={locked || !hasAudio} onPress={studio.play} />
          <Action label="Oprește redarea" icon="square" disabled={locked || !studio.seekable} onPress={studio.stop} />
          <Pressable testID="record-voice" accessibilityLabel={recording ? 'Oprește înregistrarea' : 'Înregistrează vocea'}
            accessibilityRole="button" disabled={blocked} onPress={() => record()}
            style={({ pressed }) => [st.rec, recording && st.recOn, pressed && common.pressed, blocked && common.disabled]}>
            <View style={[st.recDot, recording && st.stopDot]} />
          </Pressable>
          <Action label={studio.loop ? 'Dezactivează redarea în buclă' : 'Redă în buclă'} icon="repeat" disabled={blocked} active={studio.loop} onPress={studio.toggleLoop} />
          <View style={st.time}><Text style={[st.timeValue, recording && st.timeRec]}>{timecode(clock, true)}</Text><Text style={common.cap}>{recording ? 'REC' : 'TIMP'}</Text></View>
        </View>
        <View style={st.progress}>
          <Slider testID="mix-position" accessibilityLabel="Poziție mix" value={position} minimumValue={0} maximumValue={studio.duration || 1}
            disabled={locked || !studio.seekable} minimumTrackTintColor={c.cyan} maximumTrackTintColor={c.line} thumbTintColor={c.cyan}
            onValueChange={setScrub} onSlidingComplete={value => { setScrub(null); studio.seek(value); }} style={st.slider} />
          <Text style={st.totalTime}>{timecode(studio.duration)}</Text>
        </View>
        <View style={st.tabs}>
          {tabs.map(tab => <Pressable key={tab.id} accessibilityRole="tab" accessibilityState={{ selected: tab.id === panel }} testID={`tab-${tab.id}`}
            onPress={() => go(tab.id)} style={[st.tab, panel === tab.id && st.activeTab]}>
            <Feather name={tab.icon} size={17} color={panel === tab.id ? c.cyan : c.muted} />
            <Text numberOfLines={1} style={[st.tabName, panel === tab.id && st.activeTabName]}>{tab.title}</Text>
          </Pressable>)}
        </View>
      </View>
    </View>
  </View>;
}

const st = StyleSheet.create({
  page: { flex: 1, backgroundColor: c.bg },
  shell: { maxWidth: 780, width: '100%', flex: 1, alignSelf: 'center' },
  header: { paddingHorizontal: 16, paddingBottom: 12, backgroundColor: c.surface, flexDirection: 'row', justifyContent: 'space-between', gap: 10, alignItems: 'center' },
  identity: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  brandMark: { width: 42, height: 42, backgroundColor: c.cyanBg, borderColor: c.line, borderWidth: 1, borderRadius: 9, justifyContent: 'center', alignItems: 'center' },
  name: { color: c.text, fontSize: 21, letterSpacing: -.65, fontFamily: 'Inter_700Bold', marginBottom: 3 },
  subHeader: { backgroundColor: c.bg, borderTopWidth: 1, borderBottomWidth: 1, borderColor: c.line, paddingHorizontal: 16, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 10, justifyContent: 'space-between' },
  projectTag: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  projectDot: { backgroundColor: c.green, width: 6, height: 6, borderRadius: 4 },
  projectName: { color: c.muted, fontSize: 11, fontFamily: 'Inter_500Medium' },
  flags: { flexDirection: 'row', gap: 5 },
  flag: { paddingHorizontal: 6, paddingVertical: 4, borderColor: c.line, borderWidth: 1, borderRadius: 4, color: c.secondary, fontSize: 9, fontVariant: ['tabular-nums'], fontFamily: 'Inter_600SemiBold' },
  scroll: { flex: 1 },
  content: { padding: 14, gap: 12, paddingBottom: 20 },
  notice: { marginHorizontal: 14, marginTop: 7, padding: 7, paddingLeft: 10, borderColor: c.line, borderWidth: 1, backgroundColor: c.surface, borderRadius: 6, flexDirection: 'row', gap: 7, alignItems: 'center' },
  noticeText: { flex: 1 },
  bottom: { borderTopWidth: 1, borderColor: c.line, backgroundColor: c.surface },
  transport: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingTop: 8, gap: 6 },
  rec: { borderRadius: 6, width: 42, height: 39, backgroundColor: c.pinkBg, borderColor: c.pink, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  recOn: { backgroundColor: c.pink },
  recDot: { backgroundColor: c.pink, width: 14, height: 14, borderRadius: 8 },
  stopDot: { borderRadius: 2, backgroundColor: c.ink },
  time: { flex: 1, minWidth: 0, alignItems: 'flex-end', paddingRight: 1 },
  timeValue: { color: c.cyan, fontSize: 22, fontVariant: ['tabular-nums'], fontFamily: 'Inter_700Bold', letterSpacing: -.9 },
  timeRec: { color: c.pink },
  progress: { height: 32, flexDirection: 'row', alignItems: 'center', marginHorizontal: 14, gap: 6 },
  slider: { flex: 1, height: 32 },
  totalTime: { color: c.muted, fontSize: 10, fontVariant: ['tabular-nums'], fontFamily: 'Inter_600SemiBold' },
  tabs: { flexDirection: 'row', borderTopWidth: 1, borderColor: c.line },
  tab: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 4, height: 50, borderTopWidth: 2, borderTopColor: c.transparent },
  activeTab: { backgroundColor: c.cyanBg, borderTopColor: c.cyan },
  tabName: { color: c.muted, fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  activeTabName: { color: c.cyan },
});
