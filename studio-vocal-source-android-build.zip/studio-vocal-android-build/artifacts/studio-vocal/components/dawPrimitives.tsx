import { useState, type ReactNode } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import { studioColors as c } from '@/constants/colors';
import type { Channel } from '@/audio/runtime';

export type Glyph = keyof typeof Feather.glyphMap;
export const channels = [
  { id: 'voice', name: 'Voce', icon: 'mic', color: c.pink, tint: c.pinkBg },
  { id: 'music', name: 'Melodie', icon: 'music', color: c.blue, tint: c.blueBg },
  { id: 'beat', name: 'Beat', icon: 'grid', color: c.amber, tint: c.amberBg },
] as const satisfies ReadonlyArray<{ id: Channel; name: string; icon: Glyph; color: string; tint: string }>;

export const timecode = (seconds: number, fine = false) => {
  const t = Math.max(0, Math.floor(seconds * 100));
  const digits = (n: number) => String(n).padStart(2, '0');
  return `${digits(Math.floor(t / 6000))}:${digits(Math.floor(t / 100) % 60)}${fine ? `.${digits(t % 100)}` : ''}`;
};

export function Action({ label, icon, text, onPress, disabled, active, color }: {
  label: string; icon?: Glyph; text?: string; onPress: () => void; disabled?: boolean; active?: boolean; color?: string;
}) {
  const foreground = color ?? (active ? c.cyan : c.secondary);
  return <Pressable testID={label} accessibilityLabel={label} accessibilityRole="button" disabled={disabled}
    accessibilityState={{ selected: active, disabled }} onPress={onPress}
    style={({ pressed }) => [styles.action, active && styles.on, pressed && styles.pressed, disabled && styles.disabled]}>
    {icon && <Feather name={icon} color={foreground} size={16} />}
    {text && <Text style={[styles.actionText, { color: foreground }]}>{text}</Text>}
  </Pressable>;
}

export function PanelTitle({ code, title, right }: { code: string; title: string; right?: ReactNode }) {
  return <View style={styles.panelTitle}>
    <View style={styles.heading}><Text style={styles.cap}>{code}</Text><Text style={styles.title}>{title}</Text></View>
    {right}
  </View>;
}

export function Fader({ label, value, set, min = 0, max = 100, step = 1, unit = '%', disabled, color = c.cyan }: {
  label: string; value: number; set: (value: number) => void; min?: number; max?: number; step?: number;
  unit?: string; disabled?: boolean; color?: string;
}) {
  const [draft, setDraft] = useState<number | null>(null);
  const v = draft ?? value;
  return <View style={styles.fader}>
    <View style={styles.faderLabel}>
      <Text style={styles.body}>{label}</Text>
      <Text style={[styles.value, { color }]}>{unit === 'dB' && v > 0 ? '+' : ''}{step < 1 ? v.toFixed(2) : v}{unit === '%' ? '%' : ` ${unit}`}</Text>
    </View>
    <Slider testID={label} accessibilityLabel={label} value={value} minimumValue={min} maximumValue={max} step={step} disabled={disabled}
      minimumTrackTintColor={color} maximumTrackTintColor={c.line} thumbTintColor={color}
      onValueChange={setDraft} onSlidingComplete={next => { setDraft(null); set(next); }} style={styles.slider} />
  </View>;
}

export const styles = StyleSheet.create({
  body: { color: c.secondary, fontFamily: 'Inter_500Medium', fontSize: 13 },
  muted: { color: c.muted, fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18 },
  cap: { color: c.dim, fontFamily: 'Inter_700Bold', letterSpacing: 1.65, fontSize: 9 },
  title: { color: c.text, fontFamily: 'Inter_700Bold', letterSpacing: -.55, fontSize: 20 },
  action: { minHeight: 39, minWidth: 39, paddingHorizontal: 8, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 5, borderRadius: 6, borderWidth: 1, borderColor: c.line, backgroundColor: c.bg },
  actionText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  on: { borderColor: c.cyan, backgroundColor: c.cyanBg },
  pressed: { opacity: .65 },
  disabled: { opacity: .42 },
  panelTitle: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  heading: { gap: 4, flex: 1 },
  fader: { paddingTop: 6 },
  faderLabel: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  value: { fontFamily: 'Inter_700Bold', fontSize: 11, fontVariant: ['tabular-nums'] },
  slider: { height: 36 },
  card: { borderWidth: 1, borderColor: c.line, backgroundColor: c.surface, borderRadius: 8, padding: 12, gap: 10 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
});
