import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import Svg, { Line, Rect } from 'react-native-svg';
import type { useStudio } from '@/audio/useStudio';
import type { Channel } from '@/audio/runtime';
import { studioColors as c } from '@/constants/colors';
import { Action, Fader, PanelTitle, channels, styles as common, timecode } from './dawPrimitives';

type Studio = ReturnType<typeof useStudio>;
type Panel = 'insert' | 'beat' | 'mix';

export function Arrangement({ studio, selected, select, open }: {
  studio: Studio; selected: Channel; select: (channel: Channel) => void; open: (panel: Panel) => void;
}) {
  const [remove, setRemove] = useState<'voice' | 'music' | null>(null);
  const [width, setWidth] = useState(0);
  const { settings, tracks, hasBeat, recording, blocked } = studio;
  const locked = recording || blocked;
  const secondsPerBar = 240 / settings.beat.bpm;
  const bars = Math.max(4, Math.ceil(studio.duration / secondsPerBar));
  const stride = Math.ceil(bars / 8);
  const ticks = Array.from({ length: Math.ceil(bars / stride) }, (_, i) => i * stride);
  const span = bars * secondsPerBar;
  const percent = (seconds: number) => `${Math.min(100, Math.max(0, seconds / span * 100))}%` as const;
  const channel = channels.find(item => item.id === selected)!;
  const selectedTrack = selected === 'beat' ? undefined : tracks[selected];
  const available = (id: Channel) => id === 'beat' ? hasBeat : Boolean(tracks[id]);
  return <>
    <PanelTitle code="PROIECT / 01" title="Aranjament" right={
      <Action label="Importă melodie" icon="plus" text="Import" onPress={() => { select('music'); studio.importMusic(); }} disabled={locked} />
    } />
    <View style={st.timeline}>
      <View style={st.trackHeaders}>
        <View style={st.rulerLabel}><Text style={common.cap}>PISTE</Text></View>
        {channels.map(item => <Pressable key={item.id} testID={`track-${item.id}`} accessibilityRole="button" accessibilityLabel={`Selectează pista ${item.name}`}
          accessibilityState={{ selected: selected === item.id }} onPress={() => { select(item.id); setRemove(null); }}
          style={[st.trackLabel, selected === item.id && st.selected, { borderLeftColor: item.color }]}>
          <Feather name={item.icon} color={item.color} size={15} />
          <View style={st.trackTitle}><Text numberOfLines={1} style={st.trackName}>{item.name}</Text><Text style={st.trackType}>{item.id === 'beat' ? 'PATTERN' : 'AUDIO'}</Text></View>
        </Pressable>)}
      </View>
      <View style={st.trackArea}>
        <Pressable testID="timeline-ruler" accessibilityLabel="Poziționare pe grila de timp" disabled={!studio.seekable || locked}
          onLayout={event => setWidth(event.nativeEvent.layout.width)}
          onPress={event => { if (width) studio.seek(Math.min(studio.duration, event.nativeEvent.locationX / width * span)); }}
          style={st.ruler}>
          <View pointerEvents="none" style={StyleSheet.absoluteFill}>
            {ticks.map(bar => <Text key={bar} style={[st.tickLabel, { left: percent(bar * secondsPerBar) }]}>{String(bar + 1).padStart(2, '0')}</Text>)}
          </View>
        </Pressable>
        {channels.map(item => {
          const track = item.id === 'beat' ? undefined : tracks[item.id];
          const start = item.id === 'voice' ? studio.voiceStart : studio.backingStart;
          const duration = item.id === 'beat' ? studio.beatLength : track?.duration ?? 0;
          const muted = settings.muted[item.id] || (settings.solo && settings.solo !== item.id);
          const isRecording = item.id === 'voice' && recording;
          return <Pressable key={item.id} accessibilityRole="button" accessibilityLabel={`Pistă ${item.name}`}
            onPress={() => { select(item.id); setRemove(null); }} style={[st.lane, selected === item.id && st.laneSelected]}>
            <View pointerEvents="none" style={StyleSheet.absoluteFill}>{ticks.map(bar => <View key={bar} style={[st.gridLine, { left: percent(bar * secondsPerBar) }]} />)}</View>
            {isRecording ? <View style={[st.clip, st.recordingClip]}><Text style={st.recordingLabel}>REC {timecode(studio.recorderState.durationMillis / 1000)}</Text></View>
              : available(item.id) ? <View style={[st.clip, { left: percent(start), width: percent(duration), backgroundColor: item.tint, borderColor: item.color, opacity: muted ? .38 : 1 }]}>
                <Text numberOfLines={1} style={[st.clipName, { color: item.color }]}>{track?.name ?? `${settings.beat.kit === '808' ? '808' : 'Studio'} · ${settings.beat.bars} măsuri`}</Text>
                <Svg width="100%" height={24} viewBox="0 0 320 24" preserveAspectRatio="none">
                  {track ? track.peaks.map((peak, i) => <Line key={i} x1={2 + i * 4} x2={2 + i * 4} y1={12 - Math.max(1, peak * 11)} y2={12 + Math.max(1, peak * 11)} stroke={item.color} strokeWidth={1.6} />)
                    : Array.from({ length: 16 }, (_, step) => [...settings.beat.steps.map(row => row[step] > 0), settings.beat.bassNotes[step] >= 0].map((on, row) =>
                      on && <Rect key={`${row}-${step}`} x={step * 20 + 2} y={row * 4.5 + 1} width={12} height={2.8} rx={1} fill={item.color} opacity={.8} />))}
                </Svg>
              </View> : <Text numberOfLines={1} style={st.empty}>{item.id === 'voice' ? 'Înregistrează o voce' : item.id === 'music' ? 'Importă din telefon' : 'Construiește un pattern'}</Text>}
          </Pressable>;
        })}
        {studio.position > 0 && <View pointerEvents="none" style={[st.playhead, { left: percent(studio.position) }]} />}
      </View>
    </View>
    <View style={common.card}>
      <View style={[common.row, st.spread]}>
        <View style={common.row}>
          <View style={[st.inspectorDot, { backgroundColor: channel.color }]} />
          <View><Text style={common.cap}>INSPECTOR</Text><Text style={st.inspectorName}>{channel.name}</Text></View>
        </View>
        {selected !== 'beat' && selectedTrack && <Action label={`Elimină pista ${channel.name}`} icon="trash-2" disabled={locked} onPress={() => setRemove(selected)} />}
      </View>
      {selected === 'voice' ? <>
        <Text style={common.muted}>{selectedTrack ? `Înregistrare vocală · ${timecode(selectedTrack.duration)}` : 'Apasă REC în bara de jos pentru a înregistra.'}</Text>
        <View style={common.wrap}>
          <Action label="Deschide efectele vocale" text="Rack vocal" icon="sliders" onPress={() => open('insert')} />
          {(tracks.music || hasBeat) && <Action label="Ascultă acompaniamentul în căști" icon="headphones" text={studio.monitor ? 'Monitor pornit' : 'Monitor oprit'}
            active={studio.monitor} onPress={() => studio.setMonitor(!studio.monitor)} disabled={locked} />}
        </View>
        {studio.monitor && <Text style={common.muted}>Folosește căști ca microfonul să nu capteze acompaniamentul.</Text>}
      </> : selected === 'music' ? <>
        <Text style={common.muted}>{selectedTrack?.name ?? 'Importă o melodie MP3, M4A sau WAV, de cel mult 5 minute.'}</Text>
        <Action label={selectedTrack ? 'Schimbă melodia' : 'Alege melodie'} text={selectedTrack ? 'Schimbă fișierul' : 'Alege din telefon'} icon="folder" onPress={studio.importMusic} disabled={locked} />
      </> : <>
        <Text style={common.muted}>{hasBeat ? `${settings.beat.bpm} BPM · ${settings.beat.bars} măsuri · Kit ${settings.beat.kit === '808' ? '808' : 'Studio'}` : 'Programează tobe și o linie de bas în sequencer.'}</Text>
        <Action label="Deschide Beat Maker" text="Editează patternul" icon="grid" onPress={() => open('beat')} />
      </>}
      {remove && <View style={common.wrap}>
        <Text style={common.muted}>Elimini pista din proiect?</Text>
        <Action label="Anulează eliminarea" icon="x" onPress={() => setRemove(null)} />
        <Action label="Confirmă eliminarea pistei" icon="check" active disabled={locked} onPress={() => { studio.removeTrack(remove); setRemove(null); }} />
      </View>}
    </View>
    <View style={[common.card, st.session]}>
      <View style={st.flex}><Text style={common.cap}>SESIUNE LOCALĂ</Text><Text style={[common.muted, st.sessionCopy]}>Tobe, melodie și voce în același mix.</Text></View>
      <Action label="Deschide mixerul" icon="sliders" text="Mixer" onPress={() => open('mix')} />
    </View>
  </>;
}

export function Mixer({ studio }: { studio: Studio }) {
  const { settings, tracks, hasBeat } = studio;
  const disabled = studio.blocked || studio.recording;
  return <>
    <PanelTitle code="MIXCONSOLE / 03" title="Mixer" right={<Text style={common.cap}>STEREO OUT</Text>} />
    <View style={common.card}>
      {channels.map(channel => {
        const levelKey = channel.id === 'beat' ? 'beatLevel' : channel.id;
        const available = channel.id === 'beat' ? hasBeat : Boolean(tracks[channel.id]);
        const muted = settings.muted[channel.id], solo = settings.solo === channel.id;
        return <View key={channel.id} style={st.mixerRow}>
          <View style={[common.row, st.spread]}>
            <View style={common.row}><Feather name={channel.icon} size={16} color={channel.color} /><Text style={st.inspectorName}>{channel.name}</Text></View>
            <View style={common.row}>
              <Action label={`Mute ${channel.name}`} text="M" disabled={disabled || !available} active={muted} color={muted ? c.amber : undefined}
                onPress={() => studio.update({ muted: { ...settings.muted, [channel.id]: !muted }, ...(solo && !muted ? { solo: null } : {}) })} />
              <Action label={`Solo ${channel.name}`} text="S" disabled={disabled || !available} active={solo}
                onPress={() => studio.update({ solo: solo ? null : channel.id, muted: { ...settings.muted, [channel.id]: false } })} />
            </View>
          </View>
          <Fader label={`Volum ${channel.name.toLowerCase()}`} value={settings[levelKey]} set={value => studio.update({ [levelKey]: value })} disabled={disabled} color={channel.color} />
        </View>;
      })}
      <Fader label="Volum master" value={settings.master} set={master => studio.update({ master })} disabled={disabled} />
    </View>
    <View style={common.card}>
      <Text style={common.cap}>ALINIERE PISTE</Text>
      <Fader label="Decalaj voce" value={settings.offset} set={offset => studio.update({ offset })} min={-5} max={5} step={.05} unit="s"
        disabled={disabled || !tracks.voice || (!tracks.music && !hasBeat)} />
      <Text style={common.muted}>Valori pozitive pornesc vocea mai târziu. Valorile negative întârzie acompaniamentul.</Text>
    </View>
  </>;
}

const st = StyleSheet.create({
  timeline: { backgroundColor: c.bg, borderWidth: 1, borderColor: c.line, borderRadius: 8, flexDirection: 'row', overflow: 'hidden' },
  trackHeaders: { width: 102, backgroundColor: c.surface, borderRightWidth: 1, borderColor: c.line },
  rulerLabel: { height: 28, justifyContent: 'center', paddingLeft: 10, borderBottomWidth: 1, borderColor: c.line },
  trackLabel: { height: 70, borderLeftWidth: 3, borderBottomWidth: 1, borderBottomColor: c.line, flexDirection: 'row', alignItems: 'center', gap: 6, paddingLeft: 7, paddingRight: 4 },
  selected: { backgroundColor: c.raised },
  trackTitle: { flex: 1, gap: 4 },
  trackName: { color: c.text, fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  trackType: { color: c.muted, fontFamily: 'Inter_600SemiBold', fontSize: 8, letterSpacing: .8 },
  trackArea: { flex: 1, overflow: 'hidden' },
  ruler: { height: 28, backgroundColor: c.surface, borderBottomWidth: 1, borderColor: c.line },
  tickLabel: { position: 'absolute', top: 8, paddingLeft: 5, fontSize: 9, color: c.muted, fontFamily: 'Inter_600SemiBold' },
  lane: { height: 70, borderBottomWidth: 1, borderColor: c.line, justifyContent: 'center' },
  laneSelected: { backgroundColor: c.surface },
  gridLine: { position: 'absolute', top: 0, bottom: 0, width: 1, backgroundColor: c.line, opacity: .65 },
  empty: { color: c.dim, fontSize: 10, fontFamily: 'Inter_400Regular', paddingLeft: 12 },
  clip: { position: 'absolute', top: 9, bottom: 9, paddingHorizontal: 4, paddingTop: 5, borderRadius: 4, borderWidth: 1, overflow: 'hidden' },
  clipName: { fontSize: 9, fontFamily: 'Inter_600SemiBold', marginBottom: 3 },
  recordingClip: { left: 3, right: 3, borderColor: c.pink, backgroundColor: c.pinkBg, justifyContent: 'center', paddingLeft: 9 },
  recordingLabel: { color: c.pink, fontFamily: 'Inter_700Bold', fontSize: 12 },
  playhead: { position: 'absolute', bottom: 0, top: 0, width: 1, backgroundColor: c.cyan },
  spread: { justifyContent: 'space-between' },
  inspectorDot: { width: 5, height: 24, borderRadius: 3, marginRight: 2 },
  inspectorName: { color: c.text, fontFamily: 'Inter_600SemiBold', fontSize: 14, marginTop: 2 },
  session: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  flex: { flex: 1 },
  sessionCopy: { marginTop: 3 },
  mixerRow: { borderBottomWidth: 1, borderBottomColor: c.line },
});
