import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { studioColors as c } from '@/constants/colors';
import { noteNames } from '@/audio/beat';
import type { MixSettings } from '@/audio/runtime';
import { Action, Fader, PanelTitle, styles as common, type Glyph } from './dawPrimitives';

type Module = keyof MixSettings['bypass'];
const rack: { id: Module; icon: Glyph; name: string; desc: string; color: string }[] = [
  { id: 'tune', icon: 'activity', name: 'Pitch Correct', desc: 'Corecție de ton', color: c.pink },
  { id: 'eq', icon: 'sliders', name: 'Studio EQ', desc: 'Egalizator pe 3 benzi', color: c.cyan },
  { id: 'deEsser', icon: 'filter', name: 'De-Esser', desc: 'Reduce sibilanțele', color: c.blue },
  { id: 'compressor', icon: 'minimize-2', name: 'Compressor', desc: 'Controlează dinamica', color: c.green },
  { id: 'saturation', icon: 'zap', name: 'Saturation', desc: 'Adaugă armonice', color: c.amber },
  { id: 'echo', icon: 'repeat', name: 'Delay', desc: 'Ecou ritmic', color: c.blue },
  { id: 'reverb', icon: 'wind', name: 'Room Reverb', desc: 'Reverberație stereo', color: c.pink },
];
const clean: Partial<MixSettings> = { bass: 1, mids: -2, highs: 2, tune: 25, compressor: 46, deEsser: 38, echo: 0, saturation: 0, reverb: 12, bypass: {} };
const creative: Partial<MixSettings> = { bass: -2, mids: 1, highs: 3, tune: 90, compressor: 65, deEsser: 35, echo: 28, saturation: 22, reverb: 18, bypass: {} };
const flat: Partial<MixSettings> = { bass: 0, mids: 0, highs: 0, tune: 0, echo: 0, compressor: 0, deEsser: 0, reverb: 0, saturation: 0, bypass: {} };

export function VocalRack({ settings, update, disabled }: {
  settings: MixSettings; update: (patch: Partial<MixSettings>) => void; disabled: boolean;
}) {
  const [open, setOpen] = useState<Module | null>('tune');
  return <>
    <PanelTitle code="INSERȚII / VOCE" title="Rack vocal" right={<Action label="Resetează efectele vocale" icon="rotate-ccw" disabled={disabled} onPress={() => update(flat)} />} />
    <View style={common.card}>
      <Text style={common.cap}>PRESETURI VOCALE</Text>
      <View style={common.wrap}>
        <Action label="Preset vocal Curat" text="Voce curată" disabled={disabled} onPress={() => update(clean)} />
        <Action label="Preset vocal Modern" text="Voce modernă" disabled={disabled} onPress={() => update(creative)} />
      </View>
      <Text style={common.muted}>Module integrate. Efectele se aplică la redare și export, după înregistrare.</Text>
    </View>
    <View style={st.list}>
      {rack.map(({ id, icon, name, desc, color }, i) => {
        const expanded = open === id;
        const off = Boolean(settings.bypass[id]);
        const enabledValue = id === 'eq' ? [settings.bass, settings.mids, settings.highs].some(Boolean) : settings[id] > 0;
        return <View key={id} style={[st.module, expanded && st.expanded]}>
          <View style={st.moduleHead}>
            <Pressable testID={`plugin-${id}`} accessibilityRole="button" accessibilityLabel={name} accessibilityState={{ expanded }} onPress={() => setOpen(expanded ? null : id)} style={[common.row, st.moduleToggle]}>
              <Text style={common.cap}>{String(i + 1).padStart(2, '0')}</Text>
              <View style={st.pluginIcon}><Feather name={icon} color={color} size={17} /></View>
              <View style={st.name}><Text style={st.pluginName}>{name}</Text><Text style={st.desc}>{desc}</Text></View>
              <Feather name={expanded ? 'chevron-up' : 'chevron-down'} color={c.muted} size={15} />
            </Pressable>
            <Action label={`${off ? 'Activează' : 'Ocolește'} ${name}`} icon="power" active={!off && enabledValue} color={off ? c.dim : color} disabled={disabled}
              onPress={() => update({ bypass: { ...settings.bypass, [id]: !off } })} />
          </View>
          {expanded && <View style={st.controls}>
            {off && <Text style={common.muted}>Bypass activ · reglajele sunt păstrate.</Text>}
            {id === 'eq' ? <>
              <Fader label="Bas" value={settings.bass} set={bass => update({ bass })} min={-12} max={12} unit="dB" disabled={disabled} color={color} />
              <Fader label="Medii" value={settings.mids} set={mids => update({ mids })} min={-12} max={12} unit="dB" disabled={disabled} color={color} />
              <Fader label="Înalte" value={settings.highs} set={highs => update({ highs })} min={-12} max={12} unit="dB" disabled={disabled} color={color} />
            </> : <Fader label={id === 'tune' ? 'Corecție de ton' : id === 'echo' ? 'Ecou' : 'Intensitate'} value={settings[id]}
              set={value => update({ [id]: value })} disabled={disabled} color={color} />}
            {id === 'tune' && <>
              <View style={common.wrap}>{([['chromatic', 'Cromatic'], ['major', 'Major'], ['minor', 'Minor']] as const).map(([scale, label]) =>
                <Action key={scale} label={`Scară ${label}`} text={label} active={settings.scale === scale} disabled={disabled} onPress={() => update({ scale })} />)}</View>
              {settings.scale !== 'chromatic' && <View style={common.wrap}>{noteNames.map((note, root) =>
                <Action key={note} label={`Tonalitate ${note}`} text={note} active={settings.root === root} disabled={disabled} onPress={() => update({ root })} />)}</View>}
            </>}
          </View>}
        </View>;
      })}
    </View>
  </>;
}

const st = StyleSheet.create({
  list: { gap: 6 },
  module: { borderWidth: 1, borderColor: c.line, backgroundColor: c.surface, borderRadius: 8, overflow: 'hidden' },
  expanded: { borderColor: c.dim },
  moduleHead: { flexDirection: 'row', alignItems: 'center', paddingRight: 8, gap: 8 },
  moduleToggle: { flex: 1, minHeight: 54, paddingLeft: 9, gap: 9 },
  pluginIcon: { height: 32, width: 32, alignItems: 'center', justifyContent: 'center', borderRadius: 5, backgroundColor: c.raised },
  name: { flex: 1, gap: 3 },
  pluginName: { color: c.text, fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  desc: { color: c.muted, fontSize: 10, fontFamily: 'Inter_400Regular' },
  controls: { borderTopWidth: 1, borderColor: c.line, backgroundColor: c.bg, padding: 11, gap: 5 },
});
