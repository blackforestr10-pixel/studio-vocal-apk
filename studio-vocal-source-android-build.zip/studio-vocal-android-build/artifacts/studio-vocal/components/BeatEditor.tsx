import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { studioColors as c } from '@/constants/colors';
import { drumNames, emptyPattern, loadPattern, noteNames, type beatPresets } from '@/audio/beat';
import type { BeatSettings } from '@/audio/runtime';
import { Action, Fader, PanelTitle, styles as common } from './dawPrimitives';

const rows = [
  { color: c.pink, tint: c.pinkBg }, { color: c.blue, tint: c.blueBg },
  { color: c.cyan, tint: c.cyanBg }, { color: c.green, tint: c.greenBg },
  { color: c.amber, tint: c.amberBg },
];
const presets = [['house', 'House'], ['trap', 'Trap'], ['boomBap', 'Boom bap']] as const satisfies ReadonlyArray<readonly [keyof typeof beatPresets, string]>;

export function BeatEditor({ beat, update, disabled, activeStep }: {
  beat: BeatSettings; update: (patch: Partial<BeatSettings>) => void; disabled: boolean; activeStep: number;
}) {
  const [note, setNote] = useState(0);
  const [accent, setAccent] = useState(false);
  const [confirm, setConfirm] = useState<keyof typeof beatPresets | 'clear' | null>(null);
  const occupied = beat.steps.some(row => row.some(Boolean)) || beat.bassNotes.some(value => value >= 0);
  const applyPreset = (preset: keyof typeof beatPresets) => {
    if (occupied) setConfirm(preset);
    else update(loadPattern(preset));
  };
  function edit(row: number, step: number) {
    if (row === 4) {
      update({ bassNotes: beat.bassNotes.map((value, index) => index === step ? (value === note ? -1 : note) : value) });
      return;
    }
    const target = accent ? 2 : 1;
    update({ steps: beat.steps.map((values, i) => i === row ? values.map((value, j) => j === step ? (value === target ? 0 : target) : value) : values) });
  }
  return <>
    <PanelTitle code="INSTRUMENTE / 01" title="Beat Maker" right={<Action label="Șterge patternul" icon="trash-2" disabled={disabled || !occupied} onPress={() => setConfirm('clear')} />} />
    <View style={common.card}>
      <Text style={common.cap}>PATTERNURI DE PORNIRE</Text>
      <View style={common.wrap}>{presets.map(([id, name]) => <Action key={id} label={`Încarcă ${name}`} text={name} disabled={disabled} onPress={() => applyPreset(id)} />)}</View>
      {confirm && <View style={st.confirm}>
        <Text style={[common.muted, st.confirmText]}>{confirm === 'clear' ? 'Ștergi notele din pattern?' : 'Înlocuiești patternul curent?'}</Text>
        <Action label="Anulează" icon="x" onPress={() => setConfirm(null)} />
        <Action label="Confirmă schimbarea patternului" icon="check" active disabled={disabled} onPress={() => {
          update(confirm === 'clear' ? emptyPattern() : loadPattern(confirm));
          setConfirm(null);
        }} />
      </View>}
      <View style={[common.row, st.spread]}>
        <View style={common.row}>
          <Action label="Scade BPM" icon="minus" disabled={disabled || beat.bpm <= 55} onPress={() => update({ bpm: Math.max(55, beat.bpm - 1) })} />
          <View style={st.bpm}><Text style={st.bpmNumber}>{beat.bpm}</Text><Text style={common.cap}>BPM</Text></View>
          <Action label="Crește BPM" icon="plus" disabled={disabled || beat.bpm >= 200} onPress={() => update({ bpm: Math.min(200, beat.bpm + 1) })} />
        </View>
        <View style={common.row}>
          <Action label="Kit Studio" text="Studio" active={beat.kit === 'studio'} disabled={disabled} onPress={() => update({ kit: 'studio' })} />
          <Action label="Kit 808" text="808" active={beat.kit === '808'} disabled={disabled} onPress={() => update({ kit: '808' })} />
        </View>
      </View>
      <Fader label="Tempo" value={beat.bpm} min={55} max={200} unit="BPM" set={bpm => update({ bpm })} disabled={disabled} />
      <Fader label="Swing" value={beat.swing} max={75} set={swing => update({ swing })} disabled={disabled} />
    </View>
    <View style={common.card}>
      <View style={[common.row, st.spread]}>
        <View><Text style={common.cap}>SEQUENCER</Text><Text style={[common.body, st.sub]}>16 pași · 5 instrumente</Text></View>
        <Action label="Mod accent pentru tobe" icon="zap" text="Accent" active={accent} disabled={disabled} onPress={() => setAccent(!accent)} />
      </View>
      <View style={st.grid}>
        <View style={st.labels} pointerEvents="none">
          <View style={st.stepNumber} />
          {[...drumNames, 'Bass'].map((name, i) => <View key={name} style={st.instrument}><View style={[st.marker, { backgroundColor: rows[i].color }]} /><Text style={st.instrumentText}>{name}</Text></View>)}
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator persistentScrollbar contentContainerStyle={st.gridScroll}>
          {[0, 1, 2, 3].map(group => <View key={group} style={st.group}>
            {Array.from({ length: 4 }, (_, slot) => {
              const step = group * 4 + slot;
              return <View key={step} style={st.column}>
                <View style={[st.stepNumber, activeStep === step && st.activeNumber]}><Text style={[common.cap, activeStep === step && st.activeNumberText]}>{String(step + 1).padStart(2, '0')}</Text></View>
                {rows.map(({ color, tint }, row) => {
                  const value = row === 4 ? beat.bassNotes[step] : beat.steps[row][step];
                  const on = row === 4 ? value >= 0 : value > 0;
                  const name = row === 4 ? 'Bass' : drumNames[row];
                  return <Pressable key={row} testID={`step-${row}-${step}`} accessibilityRole="button" accessibilityState={{ selected: on, disabled }}
                    accessibilityLabel={`${name}, pasul ${step + 1}${on && row === 4 ? `, ${noteNames[value]}` : ''}`}
                    disabled={disabled} onPress={() => edit(row, step)}
                    style={({ pressed }) => [st.cell, slot === 0 && st.downbeat, on && { backgroundColor: value === 2 && row !== 4 ? color : tint, borderColor: color }, activeStep === step && !on && st.liveCell, pressed && common.pressed]}>
                    {on && (row === 4
                      ? <Text style={[st.note, { color }]}>{noteNames[value]}</Text>
                      : <View style={[st.hit, { backgroundColor: value === 2 ? c.ink : color }]} />)}
                  </Pressable>;
                })}
              </View>;
            })}
          </View>)}
        </ScrollView>
      </View>
      <Text style={common.muted}>Glisează pentru toți pașii. Alege o notă, apoi atinge o celulă de bas.</Text>
      <View style={common.wrap}>{noteNames.map((name, i) =>
        <Action key={name} label={`Notă bas ${name}`} text={name} active={i === note} disabled={disabled} onPress={() => setNote(i)} />)}</View>
      <View style={common.wrap}>
        <Text style={[common.body, st.repeatLabel]}>Repetări</Text>
        {[1, 2, 4, 8, 16].map(bars => <Action key={bars} label={`${bars} măsuri`} text={`${bars}×`} active={beat.bars === bars} disabled={disabled} onPress={() => update({ bars })} />)}
      </View>
    </View>
  </>;
}

const st = StyleSheet.create({
  spread: { justifyContent: 'space-between', flexWrap: 'wrap' },
  bpm: { minWidth: 49, alignItems: 'center', gap: 1 },
  bpmNumber: { color: c.amber, fontSize: 21, fontFamily: 'Inter_700Bold', fontVariant: ['tabular-nums'] },
  sub: { marginTop: 3 },
  grid: { flexDirection: 'row', backgroundColor: c.bg, borderColor: c.line, borderWidth: 1, borderRadius: 6, overflow: 'hidden' },
  labels: { width: 72, paddingHorizontal: 6, paddingVertical: 5, backgroundColor: c.surface, borderRightWidth: 1, borderColor: c.line, gap: 5 },
  gridScroll: { padding: 5, gap: 8, paddingBottom: 9 },
  group: { flexDirection: 'row', gap: 4 },
  column: { width: 34, gap: 5 },
  stepNumber: { height: 18, alignItems: 'center', justifyContent: 'center', borderRadius: 3 },
  activeNumber: { backgroundColor: c.cyan },
  activeNumberText: { color: c.ink },
  instrument: { height: 33, flexDirection: 'row', alignItems: 'center', gap: 4 },
  marker: { height: 11, width: 3, borderRadius: 2 },
  instrumentText: { color: c.secondary, fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  cell: { height: 33, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: c.line, borderRadius: 4, backgroundColor: c.surface },
  downbeat: { backgroundColor: c.raised },
  liveCell: { borderColor: c.cyan },
  note: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  hit: { width: 8, height: 8, borderRadius: 2 },
  repeatLabel: { flex: 1, fontSize: 11 },
  confirm: { flexDirection: 'row', gap: 5, alignItems: 'center', backgroundColor: c.raised, borderRadius: 6, padding: 6 },
  confirmText: { flex: 1 },
});
