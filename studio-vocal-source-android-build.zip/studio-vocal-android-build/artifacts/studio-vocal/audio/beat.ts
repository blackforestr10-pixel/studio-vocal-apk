import type { BeatSettings } from './runtime';

export const drumNames = ['Kick', 'Snare', 'Hi-hat', 'Open hat'];
export const noteNames = ['Do', 'Do♯', 'Re', 'Re♯', 'Mi', 'Fa', 'Fa♯', 'Sol', 'Sol♯', 'La', 'La♯', 'Si'];
export const emptyPattern = () => ({
  steps: Array.from({ length: 4 }, () => Array<number>(16).fill(0)),
  bassNotes: Array<number>(16).fill(-1),
});
export const defaultBeat: BeatSettings = { bpm: 120, bars: 4, swing: 0, kit: 'studio', ...emptyPattern() };
export const hasPattern = (beat: BeatSettings) => beat.steps.some(row => row.some(Boolean)) || beat.bassNotes.some(note => note >= 0);

export const beatPresets = {
  house: { bpm: 124, kit: 'studio', hits: [[0, 4, 8, 12], [4, 12], [0, 4, 8, 12], [2, 6, 10, 14]], bass: [[2, 0], [6, 0], [10, 7], [14, 3]] },
  trap: { bpm: 142, kit: '808', hits: [[0, 3, 7, 10, 14], [8], [0, 2, 4, 6, 8, 10, 12, 13, 14, 15], [4, 14]], bass: [[0, 0], [7, 0], [10, 3], [14, 10]] },
  boomBap: { bpm: 92, kit: 'studio', hits: [[0, 6, 10], [4, 12], [0, 2, 4, 6, 8, 10, 12, 14], [15]], bass: [[0, 5], [6, 5], [8, 8], [14, 3]] },
} as const;

export function loadPattern(preset: keyof typeof beatPresets): Partial<BeatSettings> {
  const { bpm, kit, hits, bass } = beatPresets[preset];
  const pattern = emptyPattern();
  hits.forEach((row, index) => row.forEach(step => { pattern.steps[index][step] = step % 4 === 0 ? 2 : 1; }));
  bass.forEach(([step, note]) => { pattern.bassNotes[step] = note; });
  return { ...pattern, bpm, kit };
}
