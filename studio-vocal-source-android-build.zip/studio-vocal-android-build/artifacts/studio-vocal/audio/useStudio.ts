import { useEffect, useRef, useState } from 'react';
import { Linking, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  RecordingPresets, getRecordingPermissionsAsync, requestRecordingPermissionsAsync,
  setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus, useAudioRecorder, useAudioRecorderState,
} from 'expo-audio';
import * as DocumentPicker from 'expo-document-picker';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { useAudioEngine } from './bridge';
import { defaultBeat, hasPattern } from './beat';
import type { BeatSettings, MixSettings, TrackKey, Wave } from './runtime';

const web = Platform.OS === 'web';
const storeKey = 'studio-vocal-project-v1';
const recordOptions = { ...RecordingPresets.HIGH_QUALITY, numberOfChannels: 1, isMeteringEnabled: true };
export const defaults: MixSettings = {
  bass: 0, mids: 0, highs: 0, echo: 0, tune: 0, root: 0, scale: 'chromatic', voice: 100, music: 65, offset: 0,
  beat: defaultBeat, beatLevel: 75, master: 100, muted: { voice: false, music: false, beat: false }, solo: null,
  compressor: 0, deEsser: 0, saturation: 0, reverb: 0, bypass: {},
};
export type Track = Wave & { name: string; uri: string };
type Tracks = Partial<Record<TrackKey, Track>>;
type Project = { tracks: Tracks; settings: MixSettings };

function dispose(uri?: string) {
  if (!uri) return;
  try {
    if (web) { if (uri.startsWith('blob:')) URL.revokeObjectURL(uri); }
    else { const file = new File(uri); if (file.exists) file.delete(); }
  } catch { /* the OS can clean abandoned cache files */ }
}

export function useStudio() {
  const engine = useAudioEngine();
  const recorder = useAudioRecorder(recordOptions);
  const recorderState = useAudioRecorderState(recorder, 140);
  const player = useAudioPlayer(null, { updateInterval: 100 });
  const backing = useAudioPlayer(null);
  const playback = useAudioPlayerStatus(player);
  const [project, setProject] = useState<Project>({ tracks: {}, settings: defaults });
  const current = useRef(project);
  const [busy, setBusy] = useState<string | null>(null);
  const [restoring, setRestoring] = useState(!web);
  const [recording, setRecording] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [micSettings, setMicSettings] = useState(false);
  const [monitor, setMonitor] = useState(false);
  const [loop, setLoop] = useState(false);
  const backingFile = useRef<string | null>(null);
  const lock = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cached = useRef<{ project: Project; uri: string } | null>(null);
  const restored = useRef(false);
  const storageQueue = useRef(Promise.resolve());

  useEffect(() => {
    if (web || !engine.ready || restored.current) return;
    restored.current = true;
    void (async () => {
      try {
        const raw = await AsyncStorage.getItem(storeKey);
        if (!raw) return;
        const stored = JSON.parse(raw) as Project;
        const tracks: Tracks = {};
        for (const key of ['voice', 'music'] as const) {
          const track = stored.tracks[key];
          if (!track) continue;
          try { tracks[key] = { ...track, ...await engine.load(key, track.uri) }; }
          catch { setMessage('O pistă salvată nu mai poate fi citită. Poți adăuga alta.'); }
        }
        current.current = { tracks, settings: {
          ...defaults, ...stored.settings,
          muted: { ...defaults.muted, ...stored.settings.muted },
          beat: { ...defaultBeat, ...stored.settings.beat },
        } };
        setProject(current.current);
      } catch { setMessage('Proiectul salvat nu a putut fi restaurat.'); }
      finally { setRestoring(false); }
    })();
  }, [engine.ready]);

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  function commit(next: Project, obsoleteUri?: string) {
    current.current = next;
    setProject(next);
    if (web) { dispose(obsoleteUri); return; }
    storageQueue.current = storageQueue.current.then(async () => {
      try {
        await AsyncStorage.setItem(storeKey, JSON.stringify(next));
        dispose(obsoleteUri);
      } catch { setMessage('Modificările rămân în sesiunea curentă, dar nu au putut fi salvate.'); }
    });
  }

  function update(patch: Partial<MixSettings>) {
    if (lock.current || recording || restoring) return;
    player.pause();
    commit({ ...current.current, settings: { ...current.current.settings, ...patch } });
  }

  function updateBeat(patch: Partial<BeatSettings>) {
    const settings = current.current.settings;
    const beat = { ...settings.beat, ...patch };
    update({ beat, ...(settings.solo === 'beat' && !hasPattern(beat) ? { solo: null } : {}) });
  }

  function releaseBacking() {
    backing.pause();
    backing.replace(null);
    dispose(backingFile.current ?? undefined);
    backingFile.current = null;
  }

  async function task(label: string, work: () => Promise<void>) {
    if (lock.current || !engine.ready || restoring) return;
    lock.current = true;
    setBusy(label);
    setMessage(null);
    try { await work(); }
    catch (error) { setMessage(error instanceof Error ? error.message : 'Acțiunea nu a reușit.'); }
    finally { lock.current = false; setBusy(null); }
  }

  async function attach(key: TrackKey, uri: string, name: string) {
    let target = uri;
    if (!web) {
      const original = new File(uri);
      const extension = (name.match(/\.[a-z0-9]{1,6}$/i) ?? uri.match(/\.[a-z0-9]{1,6}$/i))?.[0] ?? '.audio';
      const file = new File(Paths.document, `studio-${key}-${Date.now()}${extension}`);
      original.copy(file);
      target = file.uri;
    }
    try {
      const wave = await engine.load(key, target);
      const prev = current.current;
      player.pause();
      commit({ ...prev, tracks: { ...prev.tracks, [key]: { ...wave, name, uri: target } } }, prev.tracks[key]?.uri);
    } catch (error) {
      dispose(target);
      throw error;
    }
  }

  function importMusic() {
    if (recording) return;
    void task('Deschidem fișierele…', async () => {
      const result = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true, base64: false });
      if (result.canceled) return;
      const track = result.assets[0];
      if (track.size && track.size > 32 * 1024 * 1024) {
        if (!web) dispose(track.uri);
        throw new Error('Fișierul trebuie să aibă maximum 32 MB.');
      }
      setBusy('Citire melodie…');
      try { await attach('music', track.uri, track.name); }
      finally { if (!web) dispose(track.uri); }
    });
  }

  function stopRecording() {
    if (timer.current) { clearTimeout(timer.current); timer.current = null; }
    void task('Pregătim vocea…', async () => {
      try { await recorder.stop(); }
      finally {
        releaseBacking();
        setRecording(false);
        await setAudioModeAsync({ allowsRecording: false });
      }
      const uri = recorder.uri;
      if (!uri) throw new Error('Înregistrarea nu a putut fi salvată.');
      try { await attach('voice', uri, 'Voce înregistrată'); }
      finally { if (!web) dispose(uri); }
    });
  }

  function record() {
    if (recording) { stopRecording(); return; }
    void task('Pornim microfonul…', async () => {
      player.pause();
      let permission = await getRecordingPermissionsAsync();
      if (!permission.granted && permission.canAskAgain) permission = await requestRecordingPermissionsAsync();
      setMicSettings(!web && !permission.granted && !permission.canAskAgain);
      if (!permission.granted) throw new Error('Permite accesul la microfon ca să înregistrezi vocea.');
      try {
        const { tracks, settings } = current.current;
        const hasBacking = Boolean((tracks.music && !settings.muted.music) || (hasPattern(settings.beat) && !settings.muted.beat));
        if (monitor && hasBacking) {
          setBusy('Pregătim acompaniamentul…');
          backingFile.current = await engine.mix(tracks.music ? ['music'] : [], { ...settings, offset: 0 }, true);
          backing.replace({ uri: backingFile.current });
        }
        await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true, interruptionMode: 'mixWithOthers' });
        await recorder.prepareToRecordAsync();
        recorder.record();
        if (backingFile.current) backing.play();
        setRecording(true);
        timer.current = setTimeout(stopRecording, 299000);
      } catch (error) {
        releaseBacking();
        try { await recorder.stop(); } catch { /* recorder may not have started */ }
        await setAudioModeAsync({ allowsRecording: false });
        throw error;
      }
    });
  }

  async function render() {
    const snapshot = current.current;
    if (cached.current?.project === snapshot) return { uri: cached.current.uri, fresh: false };
    const keys = (['voice', 'music'] as const).filter(key => Boolean(snapshot.tracks[key]));
    const uri = await engine.mix(keys, snapshot.settings);
    if (cached.current) {
      player.pause();
      player.replace(null);
      dispose(cached.current.uri);
    }
    cached.current = { project: snapshot, uri };
    player.replace({ uri });
    return { uri, fresh: true };
  }

  function play() {
    if (recording) return;
    if (playback.playing) { player.pause(); return; }
    void task('Procesăm mixul…', async () => {
      await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
      const rendered = await render();
      if (!rendered.fresh && (playback.didJustFinish || playback.duration - playback.currentTime < .12)) {
        await player.seekTo(0);
      }
      player.play();
    });
  }

  function stop() {
    player.pause();
    if (playback.isLoaded) void player.seekTo(0).catch(() => setMessage('Poziția nu a putut fi resetată.'));
  }

  function exportMix() {
    if (recording) return;
    void task('Pregătim fișierul WAV…', async () => {
      player.pause();
      const { uri } = await render();
      if (web) {
        const link = document.createElement('a');
        link.href = uri;
        link.download = 'Studio-Vocal.wav';
        link.click();
      } else if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: 'audio/wav', dialogTitle: 'Exportă mixul WAV' });
      } else throw new Error('Partajarea nu este disponibilă pe acest dispozitiv.');
    });
  }

  function removeTrack(key: TrackKey) {
    if (lock.current || recording || restoring) return;
    const prev = current.current;
    const tracks = { ...prev.tracks };
    delete tracks[key];
    player.pause();
    if (key === 'music' && !hasPattern(prev.settings.beat)) setMonitor(false);
    commit({ ...prev, tracks, settings: {
      ...prev.settings, solo: prev.settings.solo === key ? null : prev.settings.solo,
      muted: { ...prev.settings.muted, [key]: false },
    } }, prev.tracks[key]?.uri);
  }

  const { tracks, settings } = project;
  const hasBeat = hasPattern(settings.beat);
  const offset = tracks.voice && (tracks.music || hasBeat) ? settings.offset : 0;
  const voiceStart = Math.max(0, offset), backingStart = Math.max(0, -offset);
  const beatLength = hasBeat ? settings.beat.bars * 240 / settings.beat.bpm : 0;
  const duration = Math.max(
    tracks.voice ? tracks.voice.duration + voiceStart + Math.max(settings.echo && !settings.bypass.echo ? 1.3 : 0, settings.reverb && !settings.bypass.reverb ? 1.4 : 0) : 0,
    tracks.music ? tracks.music.duration + backingStart : 0,
    hasBeat ? beatLength + backingStart : 0,
  );
  return {
    tracks, settings, update, record, recording, recorderState, playback, duration, monitor, setMonitor,
    play, stop, importMusic, exportMix, removeTrack, updateBeat, hasBeat, beatLength, voiceStart, backingStart,
    loop, toggleLoop: () => { player.loop = !loop; setLoop(!loop); },
    seek: (seconds: number) => { if (cached.current?.project === current.current) void player.seekTo(seconds).catch(() => setMessage('Poziția nu a putut fi schimbată.')); },
    position: cached.current?.project === project ? playback.currentTime : 0,
    seekable: cached.current?.project === project && playback.isLoaded,
    blocked: !engine.ready || restoring || Boolean(busy),
    worker: engine.worker, busy, message: engine.startupError ?? message, micSettings, openMicSettings: () => void Linking.openSettings().catch(() => setMessage('Deschide manual setările telefonului.')),
  };
}
