export type TrackKey = 'voice' | 'music';
export type Channel = TrackKey | 'beat';
export type BeatSettings = {
  bpm: number; bars: number; swing: number; kit: 'studio' | '808';
  steps: number[][]; bassNotes: number[];
};
export type MixSettings = {
  bass: number; mids: number; highs: number; echo: number;
  tune: number; root: number; scale: 'chromatic' | 'major' | 'minor';
  voice: number; music: number; offset: number;
  beat: BeatSettings; beatLevel: number; master: number;
  muted: Record<Channel, boolean>; solo: Channel | null;
  compressor: number; deEsser: number; saturation: number; reverb: number;
  bypass: Partial<Record<'eq' | 'tune' | 'echo' | 'compressor' | 'deEsser' | 'saturation' | 'reverb', boolean>>;
};
export type Wave = { duration: number; peaks: number[] };
export type EngineCommand =
  | { id: number; type: 'load'; key: TrackKey; parts: string[] }
  | { id: number; type: 'mix'; keys: TrackKey[]; settings: MixSettings; backingOnly?: boolean };
export type EngineMessage =
  | { id: number; type: 'ready' | 'done' }
  | { id: number; type: 'error'; error: string }
  | { id: number; type: 'wave'; wave: Wave }
  | { id: number; type: 'chunk'; chunk: string };

// Keep this function self-contained: Android runs the same code in a local
// WebView without network access; browser preview calls it directly.
export function makeAudioRuntime(send: (message: EngineMessage) => void) {
  const rate = 44100;
  const tracks: Partial<Record<TrackKey, AudioBuffer>> = {};
  const major = [0, 2, 4, 5, 7, 9, 11];
  const minor = [0, 2, 3, 5, 7, 8, 10];

  function correctedPitch(input: Float32Array, settings: MixSettings) {
    if (settings.tune === 0 || input.length < 4096) return input;
    const hop = 441;
    const decimation = 5;
    const windowSize = 235;
    const maxLag = 126;
    const minLag = 9;
    const offsets = new Float32Array(Math.ceil(input.length / hop));
    const periods = new Float32Array(offsets.length);
    const diff = new Float32Array(maxLag + 1);
    const low = new Float32Array(Math.floor(input.length / decimation));
    let smooth = 0;
    for (let i = 0; i < low.length; i++) {
      for (let k = 0; k < decimation; k++) smooth += .35 * (input[i * decimation + k] - smooth);
      low[i] = smooth;
    }

    for (let frame = 0; frame < periods.length; frame++) {
      const start = Math.floor(frame * hop / decimation) - Math.floor(windowSize / 2);
      if (start < 0 || start + windowSize + maxLag >= low.length) continue;
      let power = 0;
      for (let k = 0; k < windowSize; k++) power += low[start + k] ** 2;
      if (power / windowSize < .000015) continue;
      let cumulative = 0;
      let lagFound = 0;
      for (let lag = 1; lag <= maxLag; lag++) {
        let value = 0;
        for (let k = 0; k < windowSize; k++) {
          const delta = low[start + k] - low[start + k + lag];
          value += delta * delta;
        }
        cumulative += value;
        diff[lag] = cumulative ? value * lag / cumulative : 1;
        if (lag > minLag && diff[lag - 1] < .17 && diff[lag] >= diff[lag - 1]) {
          lagFound = lag - 1;
          break;
        }
      }
      if (!lagFound) continue;
      const a = diff[lagFound - 1], b = diff[lagFound], c = diff[lagFound + 1];
      const correction = Math.abs(a + c - 2 * b) > .00001 ? .5 * (a - c) / (a + c - 2 * b) : 0;
      const period = (lagFound + correction) * decimation;
      const note = 69 + 12 * Math.log2(rate / period / 440);
      let nearest = Math.round(note);
      if (settings.scale !== 'chromatic') {
        const notes = settings.scale === 'major' ? major : minor;
        let distance = Infinity;
        for (let n = Math.floor(note) - 3; n <= Math.ceil(note) + 3; n++) {
          if (notes.includes((n - settings.root + 120) % 12) && Math.abs(n - note) < distance) {
            distance = Math.abs(n - note);
            nearest = n;
          }
        }
      }
      periods[frame] = period;
      offsets[frame] = (nearest - note) * settings.tune / 100;
    }

    // Pitch-synchronous overlap-add on contiguous voiced regions. Unvoiced
    // consonants are retained from the original instead of being transposed.
    const result = input.slice();
    let region = 0;
    while (region < periods.length) {
      if (!periods[region]) { region++; continue; }
      const first = region;
      while (region < periods.length && periods[region]) region++;
      if (region - first < 3) continue;
      const start = first * hop;
      const end = Math.min(input.length, region * hop);
      const sums = new Float32Array(end - start);
      const weights = new Float32Array(end - start);
      const marks: number[] = [];
      const peakNear = (center: number, radius: number) => {
        let best = Math.round(center);
        let bestScore = -Infinity;
        for (let i = Math.max(0, Math.round(center - radius)); i <= Math.min(input.length - 1, center + radius); i++) {
          const score = input[i] - .06 * Math.abs(i - center) / radius;
          if (score > bestScore) { best = i; bestScore = score; }
        }
        return best;
      };
      let mark = peakNear(start, periods[first] * .47);
      while (mark < end) {
        marks.push(mark);
        const p = periods[Math.max(first, Math.min(region - 1, Math.floor(mark / hop)))];
        mark = peakNear(mark + p, p * .23);
      }
      if (marks.length < 3) continue;
      let j = 0;
      for (let target = marks[0]; target < end;) {
        while (j < marks.length - 1 && Math.abs(marks[j + 1] - target) < Math.abs(marks[j] - target)) j++;
        const frame = Math.max(first, Math.min(region - 1, Math.floor(target / hop)));
        const span = Math.round(periods[frame]);
        const center = Math.round(target);
        for (let k = -span; k <= span; k++) {
          const out = center + k - start;
          const src = marks[j] + k;
          if (out < 0 || out >= sums.length || src < 0 || src >= input.length) continue;
          const w = .5 + .5 * Math.cos(Math.PI * k / span);
          sums[out] += input[src] * w;
          weights[out] += w;
        }
        const next = Math.min(frame + 1, region - 1);
        const mix = Math.max(0, Math.min(1, target / hop - frame));
        const shift = offsets[frame] * (1 - mix) + offsets[next] * mix;
        target += periods[frame] / 2 ** (shift / 12);
      }
      for (let i = 0; i < sums.length; i++) {
        if (weights[i] < .05) continue;
        const blend = Math.min(1, i / 500, (sums.length - 1 - i) / 500);
        result[start + i] = input[start + i] * (1 - blend) + sums[i] / weights[i] * blend;
      }
    }
    return result;
  }

  function load(command: Extract<EngineCommand, { type: 'load' }>) {
    const decoded = command.parts.map(part => atob(part));
    const bytes = new Uint8Array(decoded.reduce((count, part) => count + part.length, 0));
    let index = 0;
    for (const part of decoded) for (let i = 0; i < part.length; i++) bytes[index++] = part.charCodeAt(i);
    const decoder = new OfflineAudioContext(1, 1, rate);
    return decoder.decodeAudioData(bytes.buffer).catch(() => {
      throw new Error('Fișierul nu poate fi decodat. Încearcă MP3, M4A sau WAV.');
    }).then(buffer => {
      if (buffer.duration > 300.05) throw new Error('Alege o pistă de maximum 5 minute.');
      tracks[command.key] = buffer;
      const data = buffer.getChannelData(0);
      const peaks = Array.from({ length: 80 }, (_, b) => {
        const start = Math.floor(data.length * b / 80);
        const end = Math.floor(data.length * (b + 1) / 80);
        let peak = 0;
        for (let i = start; i < end; i += 4) peak = Math.max(peak, Math.abs(data[i]));
        return Math.sqrt(peak);
      });
      send({ id: command.id, type: 'wave', wave: { peaks, duration: buffer.duration } });
    });
  }

  function scheduleBeat(ctx: OfflineAudioContext, output: AudioNode, beat: BeatSettings) {
    // Synthesize each percussion voice once and reuse its buffer at every step.
    const kit808 = beat.kit === '808';
    const samples = Array.from({ length: 4 }, (_, row) => {
      const duration = [kit808 ? .55 : .30, .21, .065, .28][row];
      const buffer = ctx.createBuffer(1, Math.ceil(duration * rate), rate);
      const data = buffer.getChannelData(0);
      let seed = 911 + row * 127, phase = 0, lastNoise = 0;
      for (let i = 0; i < data.length; i++) {
        const t = i / rate;
        seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
        const noise = seed / 2147483648 - 1;
        const edge = (noise - lastNoise) * .5;
        lastNoise = noise;
        phase += 2 * Math.PI * (row === 0 ? (kit808 ? 48 : 56) + 105 * Math.exp(-t * 38) : 174) / rate;
        const signal = row === 0 ? .9 * Math.sin(phase) * Math.exp(-t * (kit808 ? 8 : 17))
          : row === 1 ? .47 * (noise * .8 + Math.sin(phase) * .42) * Math.exp(-t * 27)
          : edge * (row === 2 ? .25 : .24) * Math.exp(-t * (row === 2 ? 60 : 16));
        data[i] = signal * Math.min(1, i / 44, (data.length - 1 - i) / 300);
      }
      return buffer;
    });
    const stepTime = 15 / beat.bpm;
    for (let bar = 0; bar < beat.bars; bar++) {
      for (let step = 0; step < 16; step++) {
        const start = (bar * 16 + step + (step % 2 ? beat.swing / 200 : 0)) * stepTime;
        for (let row = 0; row < samples.length; row++) {
          const level = beat.steps[row]?.[step] ?? 0;
          if (!level) continue;
          const src = ctx.createBufferSource();
          src.buffer = samples[row];
          const hit = ctx.createGain();
          hit.gain.value = level === 2 ? 1 : .67;
          src.connect(hit).connect(output);
          src.start(start);
        }
        const note = beat.bassNotes[step];
        if (note == null || note < 0) continue;
        const osc = ctx.createOscillator();
        osc.type = kit808 ? 'sine' : 'triangle';
        osc.frequency.value = 65.4064 * 2 ** (note / 12);
        const bass = ctx.createGain();
        const end = start + stepTime * .91;
        bass.gain.setValueAtTime(0, start);
        bass.gain.linearRampToValueAtTime(.34, start + .009);
        bass.gain.exponentialRampToValueAtTime(.001, end);
        osc.connect(bass).connect(output);
        osc.start(start);
        osc.stop(end);
      }
    }
  }

  function mix(command: Extract<EngineCommand, { type: 'mix' }>) {
    const settings = command.settings;
    const { beat } = settings;
    const bypass = settings.bypass;
    const echo = bypass.echo ? 0 : settings.echo;
    const reverb = bypass.reverb ? 0 : settings.reverb;
    const enabled = (channel: Channel) => !settings.muted[channel] && (!settings.solo || settings.solo === channel || command.backingOnly);
    const voice = command.keys.includes('voice') ? tracks.voice : undefined;
    const music = command.keys.includes('music') ? tracks.music : undefined;
    const hasBeat = beat.steps.some(row => row.some(Boolean)) || beat.bassNotes.some(note => note >= 0);
    if ((command.keys.includes('voice') && !voice) || (command.keys.includes('music') && !music)) {
      throw new Error('Reîncarcă pista audio înainte de mixaj.');
    }
    if (!voice && !music && !hasBeat) throw new Error('Adaugă întâi o pistă audio sau programează un beat.');
    const offset = voice && (music || hasBeat) ? settings.offset : 0;
    const voiceStart = Math.max(0, offset);
    const musicStart = Math.max(0, -offset);
    const duration = Math.max(
      voice ? voice.duration + voiceStart + Math.max(echo ? 1.3 : 0, reverb ? 1.4 : 0) : 0,
      music ? music.duration + musicStart : 0,
      hasBeat ? beat.bars * 240 / beat.bpm + musicStart : 0,
    );
    const ctx = new OfflineAudioContext(2, Math.ceil(duration * rate), rate);
    const master = ctx.createGain();
    master.gain.value = .8 * settings.master / 100;
    master.connect(ctx.destination);

    if (hasBeat && enabled('beat')) {
      const gain = ctx.createGain();
      gain.gain.value = settings.beatLevel / 100;
      const end = beat.bars * 240 / beat.bpm;
      gain.gain.setValueAtTime(gain.gain.value, end - .012);
      gain.gain.linearRampToValueAtTime(0, end);
      if (musicStart) {
        const delay = ctx.createDelay(5.1);
        delay.delayTime.value = musicStart;
        gain.connect(delay).connect(master);
      } else gain.connect(master);
      scheduleBeat(ctx, gain, beat);
    }
    if (music && enabled('music')) {
      const source = ctx.createBufferSource();
      source.buffer = music;
      const gain = ctx.createGain();
      gain.gain.value = settings.music / 100;
      source.connect(gain).connect(master);
      source.start(musicStart);
    }
    if (voice && !command.backingOnly && enabled('voice')) {
      const mono = voice.getChannelData(0).slice();
      if (voice.numberOfChannels > 1) {
        const second = voice.getChannelData(1);
        for (let i = 0; i < mono.length; i++) mono[i] = (mono[i] + second[i]) * .5;
      }
      const tuned = bypass.tune ? mono : correctedPitch(mono, settings);
      const buffer = ctx.createBuffer(1, tuned.length, rate);
      buffer.getChannelData(0).set(tuned);
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      const gain = ctx.createGain();
      gain.gain.value = settings.voice / 100;
      let endpoint: AudioNode = source;
      const bands: [BiquadFilterType, number, number][] = [
        ['lowshelf', 180, settings.bass], ['peaking', 1100, settings.mids], ['highshelf', 5500, settings.highs],
      ];
      for (const [type, frequency, db] of bypass.eq ? [] : bands) {
        const filter = ctx.createBiquadFilter();
        filter.type = type;
        filter.frequency.value = frequency;
        filter.gain.value = db;
        filter.Q.value = .8;
        endpoint.connect(filter);
        endpoint = filter;
      }
      if (settings.deEsser && !bypass.deEsser) {
        // Split off only the top band; recombine after compressing sibilants.
        const amount = settings.deEsser / 100;
        const low = ctx.createBiquadFilter();
        low.type = 'lowpass';
        low.frequency.value = 5500;
        low.Q.value = -.9;
        const invert = ctx.createGain(), high = ctx.createGain();
        invert.gain.value = -1;
        endpoint.connect(high);
        low.connect(invert).connect(high);
        const detector = ctx.createDynamicsCompressor();
        detector.threshold.value = -16 - amount * 34;
        detector.ratio.value = 1 + amount * 11;
        detector.knee.value = 10;
        detector.attack.value = .001;
        detector.release.value = .065;
        const joined = ctx.createGain();
        endpoint.connect(low).connect(joined);
        high.connect(detector).connect(joined);
        endpoint = joined;
      }
      if (settings.compressor && !bypass.compressor) {
        const amount = settings.compressor / 100;
        const node = ctx.createDynamicsCompressor();
        node.threshold.value = -12 - amount * 32;
        node.ratio.value = 1 + amount * 7;
        node.knee.value = 16;
        node.attack.value = .012;
        node.release.value = .16;
        endpoint.connect(node);
        endpoint = node;
      }
      if (settings.saturation && !bypass.saturation) {
        const node = ctx.createWaveShaper();
        const drive = 1 + settings.saturation / 15;
        const curve = new Float32Array(1025);
        for (let i = 0; i < curve.length; i++) curve[i] = Math.tanh((i / 512 - 1) * drive) / Math.tanh(drive);
        node.curve = curve;
        node.oversample = '2x';
        endpoint.connect(node);
        endpoint = node;
      }
      endpoint.connect(gain);
      gain.connect(master);
      if (echo) {
        for (let tap = 1; tap <= 5; tap++) {
          const delay = ctx.createDelay(1.3);
          delay.delayTime.value = tap * .24;
          const wet = ctx.createGain();
          wet.gain.value = echo / 100 * .65 * .46 ** (tap - 1);
          gain.connect(delay).connect(wet).connect(master);
        }
      }
      if (reverb) {
        const ir = ctx.createBuffer(2, Math.round(rate * 1.35), rate);
        let state = 2091;
        for (let channel = 0; channel < 2; channel++) {
          const data = ir.getChannelData(channel);
          for (let i = 0; i < data.length; i++) {
            state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
            const t = i / rate;
            data[i] = (state / 2147483648 - 1) * Math.min(1, t * 110) * Math.exp(-5.9 * t);
          }
        }
        const room = ctx.createConvolver();
        room.buffer = ir;
        const wet = ctx.createGain();
        wet.gain.value = reverb / 100 * .75;
        gain.connect(room).connect(wet).connect(master);
      }
      source.start(voiceStart);
    }
    return ctx.startRendering().then(buffer => {
      const left = buffer.getChannelData(0), right = buffer.getChannelData(1);
      let peak = 1;
      for (let i = 0; i < left.length; i++) peak = Math.max(peak, Math.abs(left[i]), Math.abs(right[i]));
      const header = new DataView(new ArrayBuffer(44));
      header.setUint32(0, 0x52494646); header.setUint32(4, 36 + left.length * 4, true);
      header.setUint32(8, 0x57415645); header.setUint32(12, 0x666d7420);
      header.setUint32(16, 16, true); header.setUint16(20, 1, true); header.setUint16(22, 2, true);
      header.setUint32(24, rate, true); header.setUint32(28, rate * 4, true);
      header.setUint16(32, 4, true); header.setUint16(34, 16, true);
      header.setUint32(36, 0x64617461); header.setUint32(40, left.length * 4, true);
      const emit = (bytes: Uint8Array) => {
        let text = '';
        for (let i = 0; i < bytes.length; i++) text += String.fromCharCode(bytes[i]);
        send({ id: command.id, type: 'chunk', chunk: btoa(text) });
      };
      emit(new Uint8Array(header.buffer));
      const block = 16384;
      for (let start = 0; start < left.length; start += block) {
        const count = Math.min(block, left.length - start);
        const data = new DataView(new ArrayBuffer(count * 4));
        for (let i = 0; i < count; i++) {
          data.setInt16(i * 4, Math.round(left[start + i] * 32760 / peak), true);
          data.setInt16(i * 4 + 2, Math.round(right[start + i] * 32760 / peak), true);
        }
        emit(new Uint8Array(data.buffer));
      }
      send({ id: command.id, type: 'done' });
    });
  }

  return (command: EngineCommand) => Promise.resolve()
    .then(() => command.type === 'load' ? load(command) : mix(command))
    .catch(error => send({ id: command.id, type: 'error', error: error instanceof Error ? error.message : String(error) }));
}
