import { useCallback, useEffect, useRef, useState } from 'react';
import { Platform, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';
import { File, Paths } from 'expo-file-system';
import { makeAudioRuntime, type EngineMessage, type EngineCommand, type MixSettings, type TrackKey, type Wave } from './runtime';
import { audioRuntimeSource } from './runtime-source.generated';

const html = `<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'"><script>
window.studioCommand = (${audioRuntimeSource})(function(event) {
  window.ReactNativeWebView.postMessage(JSON.stringify(event));
});
(function ready() {
  if (!window.ReactNativeWebView) { setTimeout(ready, 100); return; }
  window.ReactNativeWebView.postMessage(JSON.stringify({id:0,type:'ready'}));
})();
</script>`;
const source = { html };
const web = Platform.OS === 'web';
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function base64Bytes(text: string) {
  const size = text.length * 3 / 4 - (text.endsWith('==') ? 2 : text.endsWith('=') ? 1 : 0);
  const bytes = new Uint8Array(size);
  let out = 0;
  for (let i = 0; i < text.length; i += 4) {
    const a = alphabet.indexOf(text[i]), b = alphabet.indexOf(text[i + 1]);
    const c = Math.max(0, alphabet.indexOf(text[i + 2])), d = Math.max(0, alphabet.indexOf(text[i + 3]));
    bytes[out++] = a << 2 | b >> 4;
    if (out < size) bytes[out++] = b << 4 | c >> 2;
    if (out < size) bytes[out++] = c << 6 | d;
  }
  return bytes;
}

type Transfer = { onMessage: (message: EngineMessage) => void; fail: (error: Error) => void };

export function useAudioEngine() {
  const view = useRef<WebView<object>>(null);
  const [ready, setReady] = useState(web);
  const [startupError, setStartupError] = useState<string | null>(null);
  const pending = useRef(new Map<number, Transfer>());
  const id = useRef(0);
  const receive = useCallback((message: EngineMessage) => {
    if (message.type === 'ready') { setReady(true); setStartupError(null); }
    else pending.current.get(message.id)?.onMessage(message);
  }, []);
  const local = useRef<ReturnType<typeof makeAudioRuntime> | null>(null);
  const failPending = useCallback((message: string) => {
    for (const task of pending.current.values()) task.fail(new Error(message));
  }, []);
  useEffect(() => () => failPending('Procesarea audio a fost întreruptă.'), [failPending]);
  useEffect(() => {
    if (ready || startupError) return;
    const timeout = setTimeout(() => setStartupError('Motorul audio nu a pornit. Redeschide aplicația.'), 12000);
    return () => clearTimeout(timeout);
  }, [ready, startupError]);

  const stop = (message: string) => {
    failPending(message);
    setReady(false);
    setStartupError(message);
  };

  const dispatch = (command: EngineCommand) => {
    if (web) {
      local.current ??= makeAudioRuntime(receive);
      void local.current(command);
    } else {
      if (!view.current) throw new Error('Motorul audio nu este disponibil.');
      if (command.type === 'load') {
        const { parts, ...meta } = command;
        // Small bridge messages avoid Android's native message size limits.
        view.current.injectJavaScript(`window.studioInput = []; true;`);
        for (const part of parts) {
          view.current.injectJavaScript(`window.studioInput.push(${JSON.stringify(part)}); true;`);
        }
        view.current.injectJavaScript(`window.studioCommand(Object.assign(${JSON.stringify(meta)},{parts:window.studioInput})); window.studioInput=[]; true;`);
      } else {
        view.current.injectJavaScript(`window.studioCommand(${JSON.stringify(command)}); true;`);
      }
    }
  };

  async function load(key: TrackKey, uri: string): Promise<Wave> {
    const limit = 32 * 1024 * 1024;
    const block = 96 * 1024;
    let parts: string[];
    if (web) {
      const response = await fetch(uri);
      if (!response.ok) throw new Error('Fișierul nu poate fi citit.');
      const blob = await response.blob();
      if (blob.size > limit) throw new Error('Fișierul trebuie să aibă maximum 32 MB.');
      parts = [];
      const bytes = new Uint8Array(await blob.arrayBuffer());
      for (let i = 0; i < bytes.length; i += block) {
        let part = '';
        for (let j = i; j < Math.min(i + block, bytes.length); j++) part += String.fromCharCode(bytes[j]);
        parts.push(btoa(part));
      }
    } else {
      const file = new File(uri);
      if (!file.exists) throw new Error('Fișierul nu mai este disponibil.');
      if (file.size > limit) throw new Error('Fișierul trebuie să aibă maximum 32 MB.');
      // Each segment ends on a three-byte boundary, so it is independently decodable.
      const text = await file.base64();
      parts = text.match(/.{1,131072}/g) ?? [];
    }
    if (!parts.length) throw new Error('Fișierul audio este gol.');
    const job = ++id.current;
    return new Promise((resolve, reject) => {
      const finish = () => { clearTimeout(timeout); pending.current.delete(job); };
      const fail = (error: Error) => { finish(); reject(error); };
      const timeout = setTimeout(() => fail(new Error('Citirea fișierului audio a durat prea mult.')), 60000);
      pending.current.set(job, { fail, onMessage: message => {
        if (message.type === 'wave') { finish(); resolve(message.wave); }
        if (message.type === 'error') fail(new Error(message.error));
      } });
      try { dispatch({ id: job, type: 'load', key, parts }); }
      catch (error) { fail(error instanceof Error ? error : new Error(String(error))); }
    });
  }

  async function mix(keys: TrackKey[], settings: MixSettings, backingOnly = false): Promise<string> {
    const job = ++id.current;
    const chunks: Uint8Array<ArrayBuffer>[] = [];
    const file = web ? null : new File(Paths.cache, `Studio-Vocal-${Date.now()}-${job}.wav`);
    file?.create();
    const handle = file?.open();
    return new Promise((resolve, reject) => {
      const finish = () => { clearTimeout(timeout); pending.current.delete(job); };
      const fail = (error: Error) => {
        finish();
        try { handle?.close(); file?.delete(); } catch { /* no partial mix is used */ }
        reject(error);
      };
      const timeout = setTimeout(() => fail(new Error('Mixajul a durat prea mult. Încearcă o pistă mai scurtă.')), 120000);
      pending.current.set(job, { fail, onMessage: message => {
        try {
          if (message.type === 'chunk') {
            const bytes = base64Bytes(message.chunk);
            if (handle) handle.writeBytes(bytes);
            else chunks.push(bytes);
          }
          if (message.type === 'done') {
            handle?.close();
            const uri = file?.uri ?? URL.createObjectURL(new Blob(chunks, { type: 'audio/wav' }));
            finish();
            resolve(uri);
          }
          if (message.type === 'error') fail(new Error(message.error));
        } catch (error) { fail(error instanceof Error ? error : new Error(String(error))); }
      } });
      try { dispatch({ id: job, type: 'mix', keys, settings, backingOnly }); }
      catch (error) { fail(error instanceof Error ? error : new Error(String(error))); }
    });
  }

  const worker = web ? null : <WebView<object>
    ref={view}
    source={source}
    style={styles.worker}
    containerStyle={styles.worker}
    accessible={false}
    importantForAccessibility="no-hide-descendants"
    originWhitelist={['about:blank', 'data:*']}
    onMessage={event => {
      try { receive(JSON.parse(event.nativeEvent.data) as EngineMessage); }
      catch { stop('Motorul audio a întâmpinat o eroare. Redeschide aplicația.'); }
    }}
    onError={() => stop('Motorul audio nu a putut porni. Redeschide aplicația.')}
    onRenderProcessGone={() => stop('Motorul audio s-a oprit. Redeschide aplicația.')}
    allowFileAccess={false}
    allowFileAccessFromFileURLs={false}
    allowUniversalAccessFromFileURLs={false}
  />;
  return { ready, load, mix, worker, startupError };
}

const styles = StyleSheet.create({
  worker: { position: 'absolute', width: 1, height: 1, opacity: 0, flex: 0 },
});
