# Compilează și descarcă APK-ul Studio Vocal

Acest proiect folosește Expo pentru previzualizarea aplicației. Fluxul separat din `.github/workflows/build-studio-vocal-apk.yml` generează proiectul Android temporar, compilează un APK instalabil și îl atașează ca fișier descărcabil în GitHub Actions.

## Obține APK-ul

1. Descarcă și dezarhivează pachetul proiectului.
2. Încarcă proiectul complet într-un repository GitHub al tău; păstrează folderele `artifacts/`, `lib/`, `.github/` și fișierele `pnpm-lock.yaml`, `pnpm-workspace.yaml` și `package.json`.
3. În repository, deschide fila **Actions**.
4. Alege **Build Studio Vocal APK**, apasă **Run workflow**, apoi confirmă încă o dată.
5. După ce compilarea reușește, deschide rularea terminată și descarcă artefactul **studio-vocal-android-apk**.
6. Dezarhivează artefactul descărcat și instalează fișierul `.apk` pe dispozitivul Android. Dacă telefonul cere permisiunea de instalare, permite instalarea pentru browserul sau aplicația de fișiere folosită.

Fișierul APK este disponibil în GitHub Actions pentru **14 zile** după fiecare compilare. Nu este publicat automat în Google Play. Codul de compilare rulează în repository-ul GitHub; nu modifică previzualizarea Expo Go din Replit și nu adaugă fișiere Android generate la proiectul original.
